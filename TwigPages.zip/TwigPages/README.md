# Arcaic
PHP MVC Framework
<p>
    Make sure to copy the ExampleConfig.php file and change the 
    current configs for yourself. Also make sure to change your new
    Config.php class name from ExampleConfig to Config.
</p>
<p>
    For the Config SECRET_KEY, go to https://randomkeygen.com/ and generate a key from
    CodeIgniter Encryption Keys 256-bit generator.
</p>