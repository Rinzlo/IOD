$(document).ready(function(){
	$('.btn_menu_ope').click(function(){
		$('nav'),toggleClass('open');
	});
});
