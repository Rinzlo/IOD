-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 17, 2018 at 02:34 PM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `created_at`) VALUES
(1, 'First post', 'This is a really interesting post.', '2018-10-31 06:11:55'),
(2, 'Second post', 'This is a fascinating post!', '2018-10-31 06:11:55'),
(3, 'Third post', 'This is a very informative post.', '2018-10-31 06:11:55');

-- --------------------------------------------------------

--
-- Table structure for table `remembered_logins`
--

CREATE TABLE `remembered_logins` (
  `token_hash` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_reset_hash` varchar(64) DEFAULT NULL,
  `password_reset_expires_at` datetime DEFAULT NULL,
  `activation_hash` varchar(64) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_reset_hash`, `password_reset_expires_at`, `activation_hash`, `is_active`) VALUES
(16, 'fdasf', 'buntyf@gmail.com', '$2y$10$eYp9FIpwRNoL7.OALSYWZ.2la9p8waJrRaqRx2Pf6BDDIYNvkeDZK', NULL, NULL, NULL, 0),
(17, 'fda', 'joshuo@gmail.com', '$2y$10$Stbpl0ulcsFHewXgvwDAUOU7TYYmLZNiRdhlERP46KJ5.GCbDbZUS', NULL, NULL, NULL, 0),
(19, 'blahf', 'joshuarco@gmail.edu', '$2y$10$QlenSsyweDLXgfrtcb/D9OWW0OSii68vmYeqS6CvrWjG/KAnbKHVO', NULL, NULL, NULL, 0),
(20, 'blahf', 'joshuarco@gmail.net', '$2y$10$LR1RANl6kp0jqg2r1Dq/MeqdEgQRCcjlFdy1QOArQVjxGteYX6jCW', NULL, NULL, NULL, 0),
(21, 'something', 'joshuarco@gmail.pet', '$2y$10$p3GfR5GFbs.MrhYx1CG3.OXGdPIfEjL/suzs5j0LZdW52eAjYryCe', NULL, NULL, NULL, 0),
(22, 'ahfdas', 'joshuarco@gmail.tep', '$2y$10$lbT1QiTip6ne9SxByh.STeNUj8ZggPNAxv8uI3CjwDfB5vHK49ORm', NULL, NULL, NULL, 0),
(23, 'blah', 'joshuarco@gmail.homo', '$2y$10$6XMUoY6RLPwOeN5ADrNECuw4F61JMVwTU5/nwdc8sx213GCEWfhbC', NULL, NULL, NULL, 0),
(25, 'steve', 'joshuarco@gmail.pek', '$2y$10$AY13nq3j6/CEHcc14gpgqeapEjzbT1dokjEvhaUpumtWEjc6Xt5Fi', NULL, NULL, NULL, 0),
(26, 'bob', 'bob@gmail.com', '$2y$10$QLG7F.YTQD0VXXhZDuQGz.Jz4lLDtKWfYZ1EVsKW8Dac4GNVg9z8C', NULL, NULL, NULL, 0),
(27, '341', 'johdapsf@gmail.com', '$2y$10$GJdfyTy75z6TITvjVqdUtuF6sHdeNyYweXzNW5ABKjNb8cMMU0ZZa', NULL, NULL, NULL, 0),
(28, 'bob', 'bob@me.ah', '$2y$10$NGiAgi/wr6gAPAezFQTTtOEtY9vA8XH1yYNKGCMKxa/uVpZYVf1oy', NULL, NULL, NULL, 0),
(29, 'something', 'rinzlo@me.com', '$2y$10$.v.5fcLPEHsecFvBgFQlIuS06fgY8VnpyD4Xt8Mi/wWv0OcqqgVae', NULL, NULL, NULL, 0),
(30, 'someone', 'someone@gmail.com', '$2y$10$xFUnSiVKx2s./0bPvU.ChOkCAGvcxUa9f79swWMmF00WsGMy6eld6', NULL, NULL, NULL, 0),
(31, 'someoneelse', 'else@gmail.com', '$2y$10$sfo/nAqNDCOIHdLXC4MdienxXcbAYoWz10.1fpKl8LNrAY/q6U1va', NULL, NULL, NULL, 0),
(32, 'steve', 'joshuarco@gmail.vdu', '$2y$10$oD6/2bLJBsUZfpBSSUppJexVufi3jYmVV.P5UXUpAcCi/rDuqFbma', NULL, NULL, NULL, 0),
(33, 'ahah', 'joshuarco@gmail.pdu', '$2y$10$FrmDJfqwD6eJu/N9neK7VedgYeSLYXOsVaGe8a9G7f45bh62P9JG2', NULL, NULL, NULL, 0),
(34, 'rinz', 'joshuarco@gmail.xyz', '$2y$10$KuqvbL6q1C2IWxw0TCT1/e2R7ItgXFHAX/kvQ0A/Tghma24Eo64gi', NULL, NULL, NULL, 0),
(35, 'blah', 'joshuarco@gmail.zyx', '$2y$10$i0yRIhBBovXs1KFqbRQ16.pJPbVjovXvZ4bumGErwHkvO8s4xiLBe', NULL, NULL, NULL, 0),
(41, 'rinzlo', 'joshuarco@gmail.com', '$2y$10$VX3xi7CAiyOOXKI5Z4Pm9OKQFbrYCQ/iES2cB/gpa.GA40eMepAHe', NULL, NULL, NULL, 1),
(42, 'steve', 'joshuarco@gmail.ppp', '$2y$10$JS3x6hwB/rjIM2A.Wl6Zo.p9YEbeSUFZ7dxbQ/.nc3kjiHvPjdg8S', NULL, NULL, '1915f4321dc1b05cbe80a80f028042c385be3ad16ac55bec3a0f8157c662c861', 0),
(43, 'bob', 'joshuarco@gmail.kkk', '$2y$10$vifilExTfhk24ZNu5QZJJuFqC8HMTHWev8Nh7887V./zGKT5nZR5K', NULL, NULL, '05b672f7ee1b2532775f66ed1e8b447dfd38c9dc01a1e15d98f1773ce733bc56', 0),
(44, 'someone', 'joshuarco@gmail.comb', '$2y$10$8Hw5YtVWnbJ4hl.rGC1enesKvc0VLyG0bTdON9GrjXf4yKE0WzRdW', NULL, NULL, '1a04658de4e8ddd5c4f2dbf31c91a452a64ccc939e1ce4219869a62cd27c6619', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `remembered_logins`
--
ALTER TABLE `remembered_logins`
  ADD PRIMARY KEY (`token_hash`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_hash` (`password_reset_hash`),
  ADD UNIQUE KEY `activation_hash` (`activation_hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `remembered_logins`
--
ALTER TABLE `remembered_logins`
  ADD CONSTRAINT `remembered_logins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;