<?php
declare(strict_types=1);

namespace App;


class Config
{
	/**
	 * The name of the app
	 * @var string
	 */
	const APP_NAME = 'web-app';
	
	/**
	 * Secure protocol or not
	 * @var bool
	 */
	const SSL = false;
	
	/**
	 * @var string
	 */
	const DB_HOST = 'localhost';
	
	/**
	 * @var string
	 */
	const DB_NAME = 'sec';
	
	/**
	 * @var string
	 */
	const DB_USER = 'root';
	
	/**
	 * @var string
	 */
	const DB_PASSWORD = 'root';
	
	/**
	 * Show or hide error messages on screen
	 * @var bool
	 */
	const SHOW_ERRORS = false;
	
	/**
	 * Secret key for hashing
	 * @var string
	 */
	const SECRET_KEY = 'NbXZit5QuT7kTbBE0CO3dxTh190zSRLW';
	
	/**
	 * smtp gmail username
	 * @var string
	 */
	const MAIL_USERNAME = 'testmail.comp490';
	
	/**
	 * smtp gmail password
	 * @var string
	 */
	const MAIL_PASSWORD = 'exmpdcqgublmapao';
	
	/**
	 * smtp gmail from email
	 * @var string
	 */
	const MAIL_FROM = 'DoNotReply@gmail.com';
	
	/**
	 * smtp gmail reply to email
	 * @var string
	 */
	const MAIL_REPLY_TO = 'DoNotReply@gmail.com';
	
	/**
	 * Enable SMTP debugging
	 * 0 = off (for production use)
	 * 1 = client messages
	 * 2 = client and server messages
	 * @var int
	 */
	const SMTP_DEBUG = 0;   // will break registration if not set to 0
	
	/**
	 * re-captcha secret key
	 * @var string
	 */
	const RECAPTCHA_SECRET = '6LdtKXwUAAAAAB3q_hUbdiWfjI7p0XQ17rOwiKZW';
	
	/**
	 * re-captcha public key
	 * @var string
	 */
	const RECAPTCHA_PUBLIC = '6LdtKXwUAAAAALjsz8gYQv75y9pYYN5Ude-b-viT';
}